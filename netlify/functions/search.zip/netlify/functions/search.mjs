
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/localSymbolSearch.js
import path from "node:path";
import { fileURLToPath } from "node:url";
var __filename = fileURLToPath(import.meta.url);
var __dirname = path.dirname(__filename);
var dataPath = path.resolve(__dirname, "../../../data/symbols.json");
var MIC_PREFIXES = {
  XNAS: ["NASDAQ", "US", "USA"],
  XNYS: ["NYSE", "US", "USA"],
  XASE: ["AMEX", "NYSEAMERICAN", "US"],
  ARCX: ["ARCA", "NYSEARCA", "US"],
  BATS: ["BATS", "CBOE", "US"],
  IEXG: ["IEX", "US"],
  XASX: ["ASX", "AU", "AUS"],
  XHKG: ["HK", "HKG", "HKEX"],
  XTSE: ["TSX", "CA", "CAN"],
  XTSX: ["TSXV", "VENTURE", "CA"],
  XLON: ["LSE", "LON", "UK"],
  XETR: ["XETRA", "FRA", "DE"],
  XSWX: ["SIX", "SWX", "CH"],
  XSES: ["SGX", "SG"],
  XNSE: ["NSE", "IN"],
  XBOM: ["BSE", "IN"]
};
function normalise(str) {
  return (str || "").trim();
}
function toUpper(str) {
  return normalise(str).toUpperCase();
}
function tokeniseName(name) {
  return toUpper(name).replace(/[^A-Z0-9 ]+/g, " ").split(/\s+/).filter(Boolean);
}
function buildAliases(symbol, mic, suffix) {
  const aliases = /* @__PURE__ */ new Set();
  const upSymbol = toUpper(symbol);
  if (upSymbol) aliases.add(upSymbol);
  const prefixList = MIC_PREFIXES[mic] || [];
  prefixList.forEach((prefix) => aliases.add(`${prefix}:${upSymbol}`));
  if (suffix) aliases.add(`${upSymbol}.${suffix}`);
  if (mic) aliases.add(`${mic}:${upSymbol}`);
  return Array.from(aliases);
}
function prepareRecord(entry) {
  const symbol = toUpper(entry.symbol);
  const name = normalise(entry.name);
  const mic = toUpper(entry.mic);
  const suffix = entry.suffix ? toUpper(entry.suffix) : "";
  return {
    symbol,
    name,
    mic,
    exchange: entry.exchange || "",
    country: entry.country || "",
    currency: entry.currency || "",
    type: entry.type || "",
    suffix,
    aliases: buildAliases(symbol, mic, suffix),
    nameTokens: tokeniseName(name)
  };
}
var RECORDS = dataset.symbols.map(prepareRecord);
var RECORD_INDEX = /* @__PURE__ */ new Map();
RECORDS.forEach((record) => {
  const key = `${record.symbol}::${record.mic}`;
  if (!RECORD_INDEX.has(key)) {
    RECORD_INDEX.set(key, record);
  }
});
function scoreRecord(record, upperQuery, lowerQuery, tokens) {
  if (!upperQuery) return 0;
  let score = 0;
  if (record.symbol === upperQuery) score += 200;
  if (!score && record.aliases.includes(upperQuery)) score += 180;
  if (record.symbol.startsWith(upperQuery)) score += 120;
  if (record.aliases.some((alias) => alias.startsWith(upperQuery))) score += 90;
  const nameUpper = record.name.toUpperCase();
  if (nameUpper === upperQuery) score += 110;
  if (nameUpper.startsWith(upperQuery)) score += 80;
  if (nameUpper.includes(upperQuery)) score += 50;
  if (tokens.length) {
    const matches = tokens.filter((token) => record.nameTokens.some((nameToken) => nameToken.startsWith(token)));
    if (matches.length === tokens.length) score += 60;
    else if (matches.length > 0) score += 30;
  }
  const nameLower = record.name.toLowerCase();
  if (lowerQuery && nameLower.includes(lowerQuery)) score += 20;
  return score;
}
function searchLocalSymbols(rawQuery, { micFilter = "", limit = 25 } = {}) {
  const cleaned = normalise(rawQuery);
  const upperQuery = cleaned.toUpperCase();
  const lowerQuery = cleaned.toLowerCase();
  const tokens = cleaned.split(/\s+/).filter((token) => token.length >= 2).map((token) => token.toUpperCase());
  const filteredMic = toUpper(micFilter);
  const matches = [];
  RECORDS.forEach((record) => {
    if (filteredMic && record.mic !== filteredMic) return;
    const score = scoreRecord(record, upperQuery, lowerQuery, tokens);
    if (score <= 0) return;
    matches.push({ record, score });
  });
  matches.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    if (a.record.symbol !== b.record.symbol) return a.record.symbol.localeCompare(b.record.symbol);
    return (a.record.mic || "").localeCompare(b.record.mic || "");
  });
  return matches.slice(0, limit).map(({ record }) => ({
    symbol: record.symbol,
    name: record.name,
    exchange: record.exchange,
    mic: record.mic,
    country: record.country,
    currency: record.currency,
    type: record.type,
    suffix: record.suffix,
    source: "local"
  }));
}

// netlify/functions/lib/env.js
var TIINGO_TOKEN_ENV_KEYS = [
  "TIINGO_KEY",
  "TIINGO_API_KEY",
  "TIINGO_TOKEN",
  "TIINGO_ACCESS_TOKEN",
  "REACT_APP_TIINGO_KEY",
  "REACT_APP_TIINGO_TOKEN",
  "REACT_APP_API_KEY"
];
var readEnvValue = (key) => {
  const raw = process.env?.[key];
  if (typeof raw !== "string") return "";
  const trimmed = raw.trim();
  return trimmed ? trimmed : "";
};
var getTiingoToken = () => {
  for (const key of TIINGO_TOKEN_ENV_KEYS) {
    const value = readEnvValue(key);
    if (value) return value;
  }
  return "";
};

// netlify/functions/search.js
var corsHeaders = { "access-control-allow-origin": process.env.ALLOWED_ORIGIN || "*" };
var DEFAULT_LIMIT = 25;
var search_default = async (request) => {
  const url = new URL(request.url);
  let q = url.searchParams.get("q") || "";
  let exchangeFilter = url.searchParams.get("exchange") || "";
  const limitParam = Number.parseInt(url.searchParams.get("limit") || "", 10);
  const limit = Number.isFinite(limitParam) && limitParam > 0 ? Math.min(limitParam, 100) : DEFAULT_LIMIT;
  const colon = q.match(/^([A-Za-z]{2,5})\s*:\s*([A-Za-z0-9.\-]+)$/);
  if (colon) {
    exchangeFilter = exchangeFilter || mapPrefix(colon[1]);
    q = colon[2];
  } else {
    const dot = q.match(/^([A-Za-z0-9\-]+)\.([A-Za-z]{1,4})$/);
    if (dot) {
      q = dot[1];
      exchangeFilter = exchangeFilter || mapSuffix(dot[2]);
    }
  }
  const cleanedQuery = q.trim();
  const localMatches = cleanedQuery ? searchLocalSymbols(cleanedQuery, { micFilter: exchangeFilter, limit }) : [];
  const token = getTiingoToken();
  if (!token) {
    return Response.json({ data: localMatches }, { headers: corsHeaders });
  }
  try {
    const remoteMatches = cleanedQuery.length >= 2 ? await fetchTiingoMatches(cleanedQuery, token, exchangeFilter, limit) : [];
    const combined = mergeResults(localMatches, remoteMatches, limit);
    return Response.json({ data: combined }, { headers: corsHeaders });
  } catch (e) {
    const fallback = localMatches.length ? localMatches : [];
    return Response.json(
      { data: fallback, warning: "tiingo search failed", detail: String(e) },
      { status: 200, headers: corsHeaders }
    );
  }
};
async function fetchTiingoMatches(query, token, exchangeFilter, limit) {
  const api = new URL("https://api.tiingo.com/tiingo/utilities/search");
  api.searchParams.set("query", query);
  api.searchParams.set("token", token);
  const resp = await fetch(api);
  if (!resp.ok) {
    throw new Error(`tiingo responded with ${resp.status}`);
  }
  const body = await resp.json();
  const items = Array.isArray(body) ? body : [];
  const deduped = /* @__PURE__ */ new Map();
  for (const item of items) {
    const symbol = (item.ticker || item.permaTicker || "").toUpperCase();
    if (!symbol) continue;
    const exchangeCode = (item.exchange || item.exchangeCode || "").toUpperCase();
    const mic = mapExchangeCodeToMic(exchangeCode);
    if (exchangeFilter && mic && exchangeFilter !== mic && exchangeFilter !== exchangeCode) continue;
    const key = `${symbol}::${mic}`;
    if (deduped.has(key)) continue;
    deduped.set(key, {
      symbol,
      name: item.name || "",
      exchange: exchangeCode || "",
      mic,
      country: item.country || "",
      currency: item.currency || "",
      type: item.assetType || "",
      source: "tiingo"
    });
    if (deduped.size >= limit * 2) break;
  }
  return Array.from(deduped.values());
}
function mergeResults(primary, secondary, limit) {
  const seen = /* @__PURE__ */ new Set();
  const merged = [];
  const add = (item) => {
    if (!item || !item.symbol) return;
    const key = `${item.symbol.toUpperCase()}::${(item.mic || "").toUpperCase()}`;
    if (seen.has(key)) return;
    seen.add(key);
    merged.push(item);
  };
  primary.forEach(add);
  if (merged.length < limit) {
    secondary.forEach((item) => {
      if (merged.length >= limit) return;
      add(item);
    });
  }
  return merged.slice(0, limit);
}
function mapPrefix(prefix) {
  const up = prefix.toUpperCase();
  const aliases = {
    ASX: "XASX",
    AU: "XASX",
    AUS: "XASX",
    LSE: "XLON",
    LON: "XLON",
    HK: "XHKG",
    HKG: "XHKG",
    HKEX: "XHKG",
    HKSE: "XHKG",
    SGX: "XSES",
    NSE: "XNSE",
    BSE: "XBOM",
    TSX: "XTSE",
    TSE: "XTSE",
    JP: "XTKS",
    TYO: "XTKS",
    JPX: "XTKS",
    TSEJP: "XTKS",
    NYSE: "XNYS",
    NASDAQ: "XNAS",
    AMEX: "XASE",
    ARCA: "ARCX",
    BATS: "BATS"
  };
  if (up.startsWith("X")) return up;
  return aliases[up] || up;
}
function mapSuffix(suffix) {
  const up = suffix.toUpperCase();
  const map = {
    AX: "XASX",
    ASX: "XASX",
    AU: "XASX",
    A: "XASX",
    L: "XLON",
    LSE: "XLON",
    HK: "XHKG",
    H: "XHKG",
    HKG: "XHKG",
    TO: "XTSE",
    T: "XTKS",
    DE: "XETR",
    NS: "XNSE",
    BO: "XBOM",
    SW: "XSWX",
    SG: "XSES",
    SI: "XSES"
  };
  return map[up] || "";
}
function mapExchangeCodeToMic(code) {
  const up = (code || "").toUpperCase();
  const map = {
    NASDAQ: "XNAS",
    NASDAQCM: "XNAS",
    NASDAQGM: "XNAS",
    NASDAQGS: "XNAS",
    NAS: "XNAS",
    NYSE: "XNYS",
    NYSEARCA: "ARCX",
    "NYSE ARCA": "ARCX",
    ARCA: "ARCX",
    BATS: "BATS",
    AMEX: "XASE",
    NYSEMKT: "XASE",
    "NYSE MKT": "XASE",
    ASX: "XASX",
    TSX: "XTSE",
    TSXV: "XTSX",
    LSE: "XLON",
    LONDON: "XLON",
    HKEX: "XHKG",
    HKSE: "XHKG",
    SEHK: "XHKG",
    TSE: "XTKS",
    TOKYO: "XTKS",
    SGX: "XSES",
    NSE: "XNSE",
    BSE: "XBOM",
    SIX: "XSWX",
    SWX: "XSWX",
    ETR: "XETR"
  };
  if (up.startsWith("X") && up.length >= 3) return up;
  return map[up] || "";
}
export {
  search_default as default
};
