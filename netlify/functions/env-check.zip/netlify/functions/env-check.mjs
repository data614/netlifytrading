
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/lib/env.js
var TIINGO_TOKEN_ENV_KEYS = [
  "TIINGO_KEY",
  "TIINGO_API_KEY",
  "TIINGO_TOKEN",
  "TIINGO_ACCESS_TOKEN",
  "REACT_APP_TIINGO_KEY",
  "REACT_APP_TIINGO_TOKEN",
  "REACT_APP_API_KEY"
];
var readEnvValue = (key) => {
  const raw = process.env?.[key];
  if (typeof raw !== "string") return "";
  const trimmed = raw.trim();
  return trimmed ? trimmed : "";
};
var getTiingoToken = () => {
  for (const key of TIINGO_TOKEN_ENV_KEYS) {
    const value = readEnvValue(key);
    if (value) return value;
  }
  return "";
};
var isEnvPresent = (key) => readEnvValue(key) !== "";

// netlify/functions/env-check.js
var KEY_ALIASES = {
  EMAILJS_PRIVATE_KEY: ["EMAILJS_PRIVATE_KEY", "EMAILS_PRIVATE_KEY"],
  EMAILJS_SERVICE_ID: ["EMAILJS_SERVICE_ID", "EMAILS_SERVICE_ID"],
  EMAILJS_TEMPLATE_ID: ["EMAILJS_TEMPLATE_ID", "EMAILS_TEMPLATE_ID"]
};
var env_check_default = async () => {
  const keys = /* @__PURE__ */ new Set([
    ...TIINGO_TOKEN_ENV_KEYS,
    ...Object.keys(KEY_ALIASES)
  ]);
  Object.values(KEY_ALIASES).forEach((aliases) => {
    aliases.forEach((alias) => keys.add(alias));
  });
  const present = {};
  keys.forEach((key) => {
    present[key] = isEnvPresent(key);
  });
  for (const [canonical, aliases] of Object.entries(KEY_ALIASES)) {
    if (!present[canonical]) present[canonical] = aliases.some((alias) => present[alias]);
  }
  const chosenKey = TIINGO_TOKEN_ENV_KEYS.find((k) => isEnvPresent(k));
  const token = getTiingoToken();
  const tokenPreview = token ? `${token.slice(0, 4)}...${token.slice(-4)}` : "";
  return Response.json({ env: present, meta: { tiingo: { chosenKey, tokenPreview, hasToken: !!token } } });
};
export {
  env_check_default as default
};
