var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var sendEmail_exports = {};
__export(sendEmail_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(sendEmail_exports);
const handler = async (event) => {
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Method Not Allowed" })
    };
  }
  try {
    const {
      service_id,
      template_id,
      template_params
    } = JSON.parse(event.body || "{}");
    const envValue = (...keys) => {
      for (const key of keys) {
        if (process.env[key]) return process.env[key];
      }
      return void 0;
    };
    const SERVICE_ID = service_id || envValue("EMAILJS_SERVICE_ID", "EMAILS_SERVICE_ID");
    const TEMPLATE_ID = template_id || envValue("EMAILJS_TEMPLATE_ID", "EMAILS_TEMPLATE_ID");
    const PRIVATE_KEY = envValue("EMAILJS_PRIVATE_KEY", "EMAILS_PRIVATE_KEY");
    if (!PRIVATE_KEY || !SERVICE_ID || !TEMPLATE_ID) {
      return {
        statusCode: 500,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          error: "Missing EmailJS configuration. Ensure EMAILJS/EMAILS_PRIVATE_KEY, EMAILJS/EMAILS_SERVICE_ID and EMAILJS/EMAILS_TEMPLATE_ID are set."
        })
      };
    }
    const params = typeof template_params === "object" && template_params ? template_params : {};
    const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        // Private key auth (server-to-server)
        "Authorization": `Bearer ${PRIVATE_KEY}`
      },
      body: JSON.stringify({
        service_id: SERVICE_ID,
        template_id: TEMPLATE_ID,
        template_params: params
      })
    });
    if (!res.ok) {
      const text = await res.text();
      return {
        statusCode: res.status,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ error: "EmailJS error", details: text })
      };
    }
    return {
      statusCode: 200,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ok: true })
    };
  } catch (err) {
    return {
      statusCode: 500,
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ error: "Server error", message: err.message })
    };
  }
};
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
